Welcome to Binary Magician.
In order to launch, follow these steps:

1. Open the folder named "Web Scripts"

2. Click on "index.html" (ideally, open it with Google Chrome Version 97.0.4692.99)